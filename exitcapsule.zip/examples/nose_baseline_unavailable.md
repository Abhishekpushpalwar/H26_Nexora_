# Exit capsule: `nose` -> `pytest`

**Outcome:** `baseline_unavailable` - no baseline to compare against (candidate results reported alone)  
**Evidence strength:** `weak`  
**Generated:** 2026-10-15T07:18:09+00:00  -  schema 0.1

---

## OBSERVED - executed evidence (reproducible)

### Baseline

- Python: `3.12.3`
- Pins installed: **no**
- Baseline tests: not available

Exact install failure:
```
ERROR: Could not find a version that satisfies the requirement nose==1.3.7 (from versions: none)
ERROR: No matching distribution found for nose==1.3.7
```

### Candidate

- Patch: none supplied
- Swap: remove ['nose'], install [], uninstall after []
- Install: **yes**
- Tests: {'passed': 3, 'failed': 0, 'error': 0, 'skipped': 0, 'total': 3}
- Wall time: 4.6s (limit 40s)

Per-test comparison not possible: baseline results missing.

### status.html (normalized)

not compared: status.html missing for baseline

### Usage and coverage evidence (from usage analysis)

- usage sites in production code: 0
- never executed by baseline tests: **0**
- executed but never asserted (heuristic): 0
- private API: 0; monkeypatch/import-time patch: 0

### Gaps (execution evidence only)

_none_

---

## AI-GENERATED - Gemma output (not evidence)

> _No AI-generated content was supplied for this dependency._

---

## Open concerns (auto-filled)

- **[OBSERVED]** Baseline pins did not install on Python 3.12.3: ERROR: No matching distribution found for nose==1.3.7
- **[OBSERVED]** No characterization tests were supplied for this dependency.
