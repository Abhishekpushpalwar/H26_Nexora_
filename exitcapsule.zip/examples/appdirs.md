# Exit capsule: `appdirs` -> `platformdirs`

**Outcome:** `pass_weak_evidence` - no regressions, but the swap touches code the baseline tests never executed  
**Evidence strength:** `weak`  
**Generated:** 2026-10-15T07:16:25+00:00  -  schema 0.1

> **Read this before trusting the pass:** the tests that passed did not execute every place this dependency is used (or no coverage data was supplied). A pass is weak evidence for those sites.

---

## OBSERVED - executed evidence (reproducible)

### Baseline

- Python: `3.12.3`
- Pins installed: **yes**
- Baseline tests: {'passed': 3, 'failed': 0, 'error': 0, 'skipped': 0, 'total': 3}

### Candidate

- Patch: applied via git apply
- Swap: remove ['appdirs'], install ['platformdirs==4.2.0'], uninstall after []
- Install: **yes**
- Tests: {'passed': 3, 'failed': 0, 'error': 0, 'skipped': 0, 'total': 3}
- Wall time: 4.7s (limit 40s)

### Per-test comparison (baseline vs candidate)

regressions **0**, fixed 0, still failing 0, newly skipped 0, disappeared 0, new 0


### status.html (normalized)

identical after normalization
_Normalization: ISO timestamps, clock times, dates and latency/duration numbers replaced by placeholders._

### Usage and coverage evidence (from usage analysis)

- usage sites in production code: 2
- never executed by baseline tests: **1**: `linkwatch/paths.py:4`
- executed but never asserted (heuristic): 0
- private API: 0; monkeypatch/import-time patch: 0

### Gaps (execution evidence only)

_none_

---

## AI-GENERATED - Gemma output (not evidence)

> **Model:** gemma (synthetic selftest text)  -  **not verified by execution unless a claim below says so**
>
> **Summary**
> platformdirs is the maintained successor of appdirs.
>

---

## Open concerns (auto-filled)

- **[COVERAGE]** 1 usage site(s) were never executed by the baseline tests (linkwatch/paths.py:4); a pass here is weak evidence for that code.
- **[OBSERVED]** No characterization tests were supplied for this dependency.
