# Exit capsule: `chardet` -> `charset-normalizer`

**Outcome:** `patch_failed` - patch did not apply - nothing was executed  
**Evidence strength:** `none`  
**Generated:** 2026-10-15T07:16:26+00:00  -  schema 0.1

---

## OBSERVED - executed evidence (reproducible)

### Baseline

- Python: `3.12.3`
- Pins installed: **yes**
- Baseline tests: {'passed': 3, 'failed': 0, 'error': 0, 'skipped': 0, 'total': 3}

### Candidate

- Patch: DID NOT APPLY
- Swap: remove [], install [], uninstall after []
- Install: not reached
- Tests: not available
- Wall time: 0.0s (limit 40s)

Patch error:
```
error: linkwatch/encoding.py: No such file or directory
can't find file to patch at input line 3
Perhaps you used the wrong -p or --strip option?
The text leading up to this was:
--------------------------
|--- a/linkwatch/encoding.py
|+++ b/linkwatch/encoding.py
--------------------------
No file to patch.  Skipping patch.
1 out of 1 hunk ignored
```

### status.html (normalized)

not compared: n/a

### Usage and coverage evidence (from usage analysis)

- usage sites in production code: 0
- never executed by baseline tests: **0**
- executed but never asserted (heuristic): 0
- private API: 0; monkeypatch/import-time patch: 0

### Gaps (execution evidence only)

_none_

---

## AI-GENERATED - Gemma output (not evidence)

> _No AI-generated content was supplied for this dependency._

---

## Open concerns (auto-filled)

- **[OBSERVED]** The patch did not apply: error: linkwatch/encoding.py: No such file or directory
can't find file to patch at input line 3
Perhaps you used the wrong -p or --strip option?
The text leading up to this was:
--------------------------
|--- a/linkwatch/encoding.py
|+++ b/linkwatch/encoding.py
--------------------------
No file t
- **[OBSERVED]** No characterization tests were supplied for this dependency.
