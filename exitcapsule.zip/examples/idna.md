# Exit capsule: `idna` -> `?`

**Outcome:** `no_plan` - no plan from the migration step - nothing was executed  
**Evidence strength:** `none`  
**Generated:** 2026-10-15T07:16:30+00:00  -  schema 0.1

---

## OBSERVED - executed evidence (reproducible)

### Baseline

- Python: `3.12.3`
- Pins installed: **yes**
- Baseline tests: {'passed': 3, 'failed': 0, 'error': 0, 'skipped': 0, 'total': 3}

### Candidate

No plan was supplied for this dependency, so nothing was executed.


### Usage and coverage evidence (from usage analysis)

- usage sites in production code: 0
- never executed by baseline tests: **0**
- executed but never asserted (heuristic): 0
- private API: 0; monkeypatch/import-time patch: 0

### Gaps (execution evidence only)

_none_

---

## AI-GENERATED - Gemma output (not evidence)

> _No AI-generated content was supplied for this dependency._

---

## Open concerns (auto-filled)

- **[RUN]** No plan (patch/swap) exists for this dependency, so no candidate was built or run.
