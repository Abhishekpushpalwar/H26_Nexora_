These capsules are SYNTHETIC: produced by `python -m exitcapsule selftest` on a toy repo with fake packages and a fake
pytest, to show the format and each outcome. They say nothing about the real toml/appdirs/... swaps.
Replace this folder with capsules from the real run (`./demo.sh <repo>`) before the demo.
