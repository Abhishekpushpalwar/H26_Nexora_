# Exit capsule: `toml` -> `tomllib`

**Outcome:** `regressions` - previously passing tests fail after the swap  
**Evidence strength:** `observed_failure`  
**Generated:** 2026-10-15T07:16:21+00:00  -  schema 0.1

---

## OBSERVED - executed evidence (reproducible)

### Baseline

- Python: `3.12.3`
- Pins installed: **yes**
- Baseline tests: {'passed': 3, 'failed': 0, 'error': 0, 'skipped': 0, 'total': 3}

### Candidate

- Patch: applied via git apply
- Swap: remove ['toml'], install [], uninstall after []
- Install: **yes**
- Tests: {'passed': 3, 'failed': 1, 'error': 0, 'skipped': 0, 'total': 4}
- Wall time: 4.1s (limit 40s)

### Per-test comparison (baseline vs candidate)

regressions **1**, fixed 0, still failing 0, newly skipped 0, disappeared 0, new 0

| test | before | after | error | traceback line |
|---|---|---|---|---|
| `tests.test_config::test_dump` (repo) | passed | failed | AttributeError: module 'tomllib' has no attribute 'dumps' | `linkwatch/config.py:9` |

### status.html (normalized)

identical after normalization
_Normalization: ISO timestamps, clock times, dates and latency/duration numbers replaced by placeholders._

### Usage and coverage evidence (from usage analysis)

- usage sites in production code: 2
- never executed by baseline tests: **0**
- executed but never asserted (heuristic): 0
- private API: 0; monkeypatch/import-time patch: 0

### Gaps (execution evidence only)

- `test_regression` tests.test_config::test_dump AttributeError: module 'tomllib' has no attribute 'dumps' (linkwatch/config.py:9)

---

## AI-GENERATED - Gemma output (not evidence)

> **Model:** gemma (synthetic selftest text)  -  **not verified by execution unless a claim below says so**
>
> **Summary**
> toml.loads maps to tomllib.loads; toml.dumps has no stdlib equivalent.
>
> **Claims**
> - tomllib is a drop-in for toml.loads and toml.dumps
>
> **Validation failures (model output that failed checks)**
> - claim 'drop-in for toml.dumps' not supported by the usage analysis

---

## Open concerns (auto-filled)

- **[OBSERVED]** tests.test_config::test_dump passed before, failed after: AttributeError: module 'tomllib' has no attribute 'dumps' (linkwatch/config.py:9)
- **[AI]** claim 'drop-in for toml.dumps' not supported by the usage analysis
