#!/usr/bin/env python3
"""usage.py - dependency usage finder and coverage join (Person B).

For every target dependency this records, with file:line and a ~5 line snippet:
  * every import (aliases resolved: ``from requests import Session as S``)
  * every call and every non-call attribute access (``S().get``, ``requests.codes.ok``)
  * private API use (any name segment starting with ``_``)
  * import-for-side-effect (``from . import http_patch`` whose module monkeypatches a dep)
  * monkeypatching (``requests.Session.request = ...``, setattr, mock.patch strings)
It then runs the baseline tests under coverage (JSON) and joins per usage line:
  covered  - the statement holding the usage line was executed
  asserted - HEURISTIC: covered AND the enclosing function is reachable from a function
             whose result (or raised exception, or mock-call check) a test asserts on.

Outputs (in --out-dir, default usage_out/):
  usage.json     full records + summary          imports.json  (name, file, line) for Person A
  handoff.json / handoff.md   uncovered or unasserted usages, grouped by function, for Person C

Usage:
  python usage.py                       # auto-detect deps, run tests under coverage, report
  python usage.py --deps requests,appdirs --coverage coverage.json   # reuse a coverage JSON
  python usage.py --no-coverage         # structural analysis only (covered/asserted = ?)
"""
from __future__ import annotations

import argparse
import ast
import json
import os
import re
import shlex
import subprocess
import sys
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path

SKIP_DIRS = {"__pycache__", ".venv", "venv", "env", "node_modules", "site-packages", ".git", ".tox"}
EXEC_KINDS = {"call", "attribute", "reference", "monkeypatch"}   # real code usage
NA_KINDS = {"import", "side_effect_import", "mock_patch", "string_ref"}  # "asserted" not meaningful
RAISES_NAMES = {"raises", "assertRaises", "assertRaisesRegex", "warns", "assertWarns"}
MOCK_ASSERT_RE = re.compile(r"^assert_(called|any_call|has_calls|not_called|awaited|not_awaited)")
KNOWN_IMPORT_NAMES = {
    "beautifulsoup4": ["bs4"], "pyyaml": ["yaml"], "python-dateutil": ["dateutil"],
    "pillow": ["PIL"], "scikit-learn": ["sklearn"], "attrs": ["attr", "attrs"],
    "pyjwt": ["jwt"], "python-dotenv": ["dotenv"], "opencv-python": ["cv2"],
    "pycryptodome": ["Crypto"], "protobuf": ["google.protobuf"], "msgpack-python": ["msgpack"],
}


# --------------------------------------------------------------------------- helpers
def norm_dist(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def is_private_rest(rest: str) -> bool:
    """True if any segment after the dependency root starts with _ (dunders excluded)."""
    for seg in rest.split("."):
        seg = seg.replace("()", "")
        if seg.startswith("_") and not (seg.startswith("__") and seg.endswith("__")):
            return True
    return False


def make_snippet(lines: list[str], line: int, size: int = 5) -> str:
    n = len(lines)
    if n == 0:
        return ""
    start = max(1, line - size // 2)
    end = min(n, start + size - 1)
    start = max(1, end - size + 1)
    out = []
    for i in range(start, end + 1):
        mark = ">" if i == line else " "
        out.append(f"{mark}{i:>5} | {lines[i - 1].rstrip()}")
    return "\n".join(out)


def module_name_for(rel: str) -> str:
    parts = list(Path(rel).with_suffix("").parts)
    if parts and parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def key_of(node) -> str | None:
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return None


# --------------------------------------------------------------------------- dependencies
def parse_req_name(line: str) -> str | None:
    line = line.split("#", 1)[0].strip()
    if not line or line.startswith(("-", "git+", "http")):
        return None
    m = re.match(r"([A-Za-z0-9][A-Za-z0-9._-]*)", line)
    return m.group(1) if m else None


def read_manifest_deps(root: Path) -> tuple[list[str], list[str]]:
    names, sources = [], []

    def add(n, src):
        if n and norm_dist(n) != "python" and norm_dist(n) not in [norm_dist(x) for x in names]:
            names.append(n)
        if src not in sources:
            sources.append(src)

    for p in sorted(root.glob("requirements*.txt")):
        for line in p.read_text(errors="replace").splitlines():
            add(parse_req_name(line), p.name)
    pp = root / "pyproject.toml"
    if pp.exists():
        try:
            import tomllib  # py3.11+
            data = tomllib.loads(pp.read_text())
            proj = data.get("project", {})
            for r in proj.get("dependencies", []):
                add(parse_req_name(r), "pyproject.toml")
            for rs in proj.get("optional-dependencies", {}).values():
                for r in rs:
                    add(parse_req_name(r), "pyproject.toml")
            for k in data.get("tool", {}).get("poetry", {}).get("dependencies", {}):
                add(k, "pyproject.toml")
        except Exception as e:  # pragma: no cover
            print(f"warning: could not parse pyproject.toml: {e}", file=sys.stderr)
    return names, sources


def import_names_for(dist: str, overrides: dict[str, list[str]]) -> list[str]:
    n = norm_dist(dist)
    if n in overrides:
        return overrides[n]
    names = list(KNOWN_IMPORT_NAMES.get(n, []))
    try:
        from importlib.metadata import packages_distributions
        for top, dists in packages_distributions().items():
            if n in {norm_dist(d) for d in dists} and top not in names and not top.startswith("_"):
                names.append(top)
    except Exception:
        pass
    guess = n.replace("-", "_")
    if guess not in names:
        names.append(guess)
    return names


class DepMatcher:
    def __init__(self, dep_modules: dict[str, list[str]]):
        self.by_import: dict[str, str] = {}
        for dist, mods in dep_modules.items():
            for m in mods:
                self.by_import[m] = dist
        self._order = sorted(self.by_import, key=len, reverse=True)

    def match(self, dotted: str | None):
        """-> (dist, import_name, rest) or None. dotted may contain '()' markers."""
        if not dotted:
            return None
        for m in self._order:
            if dotted == m or dotted.startswith(m + ".") or dotted.startswith(m + "("):
                return self.by_import[m], m, dotted[len(m):].lstrip(".")
        return None


# --------------------------------------------------------------------------- records
@dataclass
class Usage:
    dep: str
    kind: str          # import|call|attribute|reference|monkeypatch|mock_patch|string_ref|side_effect_import
    symbol: str
    file: str
    line: int
    end_line: int
    func: str          # enclosing "module:Qual.name" or "module:<module>"
    in_tests: bool
    cov_lines: list = field(default_factory=list)   # statement lines to look up in coverage
    local_name: str = ""
    private: bool = False
    side_effect: bool = False
    inferred: bool = False
    note: str = ""
    snippet: str = ""
    covered: object = None        # True / False / None (unknown)
    asserted: object = None       # True / False / None (n/a)
    asserted_by: list = field(default_factory=list)
    assert_kind: str = ""

    def key(self):
        return (self.file, self.line, self.kind, self.symbol)


@dataclass
class FuncInfo:
    qual: str
    an: "FileAnalyzer"
    scope_parts: list
    cls: str | None
    node: ast.AST
    start: int
    end: int
    is_test_fn: bool


@dataclass
class Binding:
    bound: str
    target_module: str | None      # local module this import brings in (if any)
    is_module_import: bool
    dep: str | None
    line: int
    usage: Usage | None = None


# --------------------------------------------------------------------------- per-file analysis
class FileAnalyzer(ast.NodeVisitor):
    def __init__(self, relpath, source, tree, module, is_test, local_modules, matcher):
        self.relpath = relpath
        self.lines = source.splitlines()
        self.tree = tree
        self.module = module
        self.is_test = is_test
        self.is_init = Path(relpath).name == "__init__.py"
        self.package = module if self.is_init else module.rpartition(".")[0]
        self.local_modules = local_modules
        self.matcher = matcher
        self.alias: dict[str, str] = {}
        self.self_types: dict[str, str] = {}
        self.type_scopes: list[dict] = [{}]
        self.scope: list[str] = []
        self.scope_kinds: list[str] = []
        self.stmt_stack: list = []
        self.usages: list[Usage] = []
        self.bindings: list[Binding] = []
        self.functions: dict[str, FuncInfo] = {}
        self.func_calls: dict[str, list] = defaultdict(list)
        self._skip: set[int] = set()
        self._consumed: set[int] = set()
        self._inf = False
        self._pure = False
        self.used_names: set[str] = set()
        self.all_names: set[str] = set()
        self._prepass()

    # ---- pre-pass: aliases, self-attribute types, used names
    def resolve_from(self, node: ast.ImportFrom) -> str | None:
        if node.level == 0:
            return node.module or ""
        pkg = self.package.split(".") if self.package else []
        keep = len(pkg) - (node.level - 1)
        if keep < 0:
            return None
        parts = pkg[:keep] + ([node.module] if node.module else [])
        return ".".join(parts)

    def _prepass(self):
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    if a.asname:
                        self.alias[a.asname] = a.name
                    else:
                        top = a.name.split(".")[0]
                        self.alias[top] = top
            elif isinstance(node, ast.ImportFrom):
                base = self.resolve_from(node)
                if base is None:
                    continue
                for a in node.names:
                    if a.name != "*":
                        self.alias[a.asname or a.name] = f"{base}.{a.name}" if base else a.name
            elif isinstance(node, ast.Name):
                self.used_names.add(node.id)
            elif isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Name) and t.id == "__all__" and isinstance(node.value, (ast.List, ast.Tuple)):
                        for e in node.value.elts:
                            if isinstance(e, ast.Constant) and isinstance(e.value, str):
                                self.all_names.add(e.value)
        for node in ast.walk(self.tree):
            if isinstance(node, (ast.Assign, ast.AnnAssign)) and getattr(node, "value", None) is not None:
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                for t in targets:
                    k = key_of(t)
                    if k and k.startswith(("self.", "cls.")):
                        d, _, _ = self.resolve(node.value)
                        if d and self.matcher.match(d):
                            self.self_types[k] = d

    # ---- name resolution
    def lookup_type(self, key):
        for sc in reversed(self.type_scopes):
            if key in sc:
                return sc[key]
        return self.self_types.get(key)

    def _set_type(self, key, d):
        if key.startswith(("self.", "cls.")):
            if d:
                self.self_types[key] = d
            return
        if d:
            self.type_scopes[-1][key] = d
        else:
            self.type_scopes[-1].pop(key, None)

    def resolve(self, node):
        """-> (dotted | None, inferred_via_variable, is_bare_variable)."""
        self._inf = False
        self._pure = False
        d = self._dotted(node, True)
        return d, self._inf, self._pure

    def _dotted(self, node, top=False):
        if isinstance(node, ast.Await):
            return self._dotted(node.value)
        if isinstance(node, ast.Call):
            d = self._dotted(node.func)
            return d + "()" if d else None
        if isinstance(node, (ast.Name, ast.Attribute)):
            parts, cur = [], node
            while isinstance(cur, ast.Attribute):
                parts.append(cur.attr)
                cur = cur.value
            parts.reverse()
            if isinstance(cur, (ast.Call, ast.Await)):
                base = self._dotted(cur)
                return ".".join([base] + parts) if base else None
            if isinstance(cur, ast.Name):
                root = cur.id
                for i in range(len(parts), -1, -1):
                    t = self.lookup_type(".".join([root] + parts[:i]))
                    if t is not None:
                        rest = parts[i:]
                        self._inf = True
                        if not rest and top:
                            self._pure = True
                        return ".".join([t] + rest) if rest else t
                if root in self.alias:
                    return ".".join([self.alias[root]] + parts)
        return None

    # ---- recording
    def cur_qual(self):
        return f"{self.module}:{'.'.join(self.scope)}" if self.scope else f"{self.module}:<module>"

    def _stmt_lines(self):
        lines = []
        for s in reversed(self.stmt_stack):
            if hasattr(s, "lineno"):
                lines.append(s.lineno)
                for d in getattr(s, "decorator_list", []) or []:
                    lines.append(d.lineno)
                break
        return lines

    def add(self, kind, symbol, node, dep=None, inferred=False, local="", note="", rest=None):
        m = self.matcher.match(symbol)
        if dep is None:
            if not m:
                return None
            dep, rest = m[0], m[2]
        u = Usage(
            dep=dep, kind=kind, symbol=symbol, file=self.relpath, line=node.lineno,
            end_line=getattr(node, "end_lineno", node.lineno) or node.lineno,
            func=self.cur_qual(), in_tests=self.is_test,
            cov_lines=[node.lineno] + self._stmt_lines(), local_name=local,
            private=is_private_rest(rest or ""), inferred=inferred, note=note,
            snippet=make_snippet(self.lines, node.lineno),
        )
        self.usages.append(u)
        return u

    def _mark_chain(self, node):
        while isinstance(node, (ast.Attribute, ast.Name)):
            self._skip.add(id(node))
            if isinstance(node, ast.Attribute):
                node = node.value
            else:
                break

    # ---- scoping
    def visit(self, node):
        is_stmt = isinstance(node, (ast.stmt, ast.excepthandler))
        if is_stmt:
            self.stmt_stack.append(node)
        is_scope = isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        is_func = isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        if is_scope:
            self.scope.append(node.name)
            self.scope_kinds.append("func" if is_func else "class")
            if is_func:
                self.type_scopes.append({})
                self._register_function(node)
                self._seed_param_types(node)
        try:
            return super().visit(node)
        finally:
            if is_scope:
                if is_func:
                    self.type_scopes.pop()
                self.scope.pop()
                self.scope_kinds.pop()
            if is_stmt:
                self.stmt_stack.pop()

    def _register_function(self, node):
        cls = None
        for name, kind in zip(reversed(self.scope[:-1]), reversed(self.scope_kinds[:-1])):
            if kind == "class":
                cls = name
                break
        start = min([node.lineno] + [d.lineno for d in node.decorator_list])
        qual = self.cur_qual()
        self.functions[qual] = FuncInfo(
            qual=qual, an=self, scope_parts=list(self.scope), cls=cls, node=node,
            start=start, end=node.end_lineno or node.lineno,
            is_test_fn=self.is_test and node.name.startswith("test"),
        )

    def _seed_param_types(self, node):
        a = node.args
        for arg in list(a.posonlyargs) + list(a.args) + list(a.kwonlyargs) + [x for x in (a.vararg, a.kwarg) if x]:
            if arg.annotation is None or isinstance(arg.annotation, ast.Constant):
                continue
            for sub in ast.walk(arg.annotation):
                if isinstance(sub, (ast.Name, ast.Attribute)):
                    d, _, _ = self.resolve(sub)
                    if d and self.matcher.match(d):
                        self.type_scopes[-1][arg.arg] = d + "()"
                        break

    # ---- imports
    def visit_Import(self, node):
        for a in node.names:
            full = a.name
            bound = a.asname or full.split(".")[0]
            m = self.matcher.match(full)
            u = self.add("import", full, node, local=bound) if m else None
            tm = full if full in self.local_modules else None
            self.bindings.append(Binding(bound, tm, tm is not None, m[0] if m else None, node.lineno, u))

    def visit_ImportFrom(self, node):
        base = self.resolve_from(node)
        if base is None:
            return
        for a in node.names:
            full = f"{base}.*" if a.name == "*" else (f"{base}.{a.name}" if base else a.name)
            bound = a.asname or a.name
            m = self.matcher.match(full)
            u = self.add("import", full, node, local=bound) if m else None
            if a.name != "*" and full in self.local_modules:
                tm, is_mod = full, True          # from . import http_patch
            elif base in self.local_modules:
                tm, is_mod = base, False         # from .http_patch import x
            else:
                tm, is_mod = None, False
            if u or tm:
                self.bindings.append(Binding(bound, tm, is_mod, m[0] if m else None, node.lineno, u))

    # ---- expressions
    def visit_Expr(self, node):
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            return  # docstring / bare string
        self.generic_visit(node)

    def visit_Constant(self, node):
        v = node.value
        if isinstance(v, str) and id(node) not in self._consumed and re.fullmatch(r"[A-Za-z_]\w*(\.[A-Za-z_]\w*)*", v):
            m = self.matcher.match(v)
            if m:
                self.add("string_ref", v, node, note="string constant naming the dependency (low confidence)")

    def visit_Name(self, node):
        if id(node) in self._skip or not isinstance(node.ctx, ast.Load):
            return
        if node.id in self.alias and not self.lookup_type(node.id):
            d = self.alias[node.id]
            if self.matcher.match(d):
                self.add("reference", d, node, local=node.id)

    def visit_Attribute(self, node):
        if id(node) in self._skip:
            self._mark_chain(node.value)
            self.generic_visit(node)
            return
        d, inf, pure = self.resolve(node)
        self._mark_chain(node.value)
        if d and not pure and self.matcher.match(d):
            kind = "monkeypatch" if isinstance(node.ctx, (ast.Store, ast.Del)) else "attribute"
            self.add(kind, d, node, inferred=inf, local=(key_of(node) or "").split(".")[0])
        self.generic_visit(node)

    def visit_Call(self, node):
        if self.scope:
            self.func_calls[self.cur_qual()].append(node)
        d, inf, pure = self.resolve(node.func)
        self._mark_chain(node.func)
        if d and not pure and self.matcher.match(d):
            self.add("call", d, node, inferred=inf, local=(key_of(node.func) or "").split(".")[0])
        self._patch_calls(node)
        self.generic_visit(node)

    def _patch_calls(self, node):
        f = node.func
        last = f.attr if isinstance(f, ast.Attribute) else (f.id if isinstance(f, ast.Name) else None)
        if last is None:
            return
        parent = key_of(f.value) or "" if isinstance(f, ast.Attribute) else ""
        args = node.args

        def str_arg(i):
            if len(args) > i and isinstance(args[i], ast.Constant) and isinstance(args[i].value, str):
                return args[i].value
            return None

        if last == "patch" and args:
            self._patch_string(node, args[0], str_arg(0))
        elif last == "object" and parent.endswith("patch") and len(args) >= 2:
            d, _, _ = self.resolve(args[0])
            name = str_arg(1)
            if d and name and self.matcher.match(d):
                self.add("mock_patch", f"{d}.{name}", node, note="patch.object on dependency")
        elif last in ("setattr", "delattr") and args:
            builtin = isinstance(f, ast.Name)
            if str_arg(0) and not builtin:
                self._patch_string(node, args[0], str_arg(0))
                return
            d, inf, _ = self.resolve(args[0])
            name = str_arg(1) or "<dynamic>"
            if d and self.matcher.match(d):
                self.add("monkeypatch" if builtin else "mock_patch", f"{d}.{name}", node, inferred=inf,
                         note=f"{last}() on dependency")

    def _patch_string(self, node, argnode, s):
        if not s:
            return
        self._consumed.add(id(argnode))
        m = self.matcher.match(s)
        if m:
            self.add("mock_patch", s, node, note="patch target string")
            return
        segs = s.split(".")
        for i in range(1, len(segs)):
            if segs[i] in self.matcher.by_import:
                dist = self.matcher.by_import[segs[i]]
                self.add("mock_patch", s, node, dep=dist, rest=".".join(segs[i + 1:]),
                         note="patched through a project module namespace")
                return

    # ---- assignments (type tracking + monkeypatch via Store ctx)
    def visit_Assign(self, node):
        self.visit(node.value)
        for t in node.targets:
            self.visit(t)
        d, _, _ = self.resolve(node.value)
        d = d if d and self.matcher.match(d) else None
        for t in node.targets:
            k = key_of(t)
            if k:
                self._set_type(k, d)

    def visit_AnnAssign(self, node):
        self.visit(node.annotation)
        if node.value is not None:
            self.visit(node.value)
        self.visit(node.target)
        d = None
        if node.value is not None:
            d, _, _ = self.resolve(node.value)
        if not d:
            d, _, _ = self.resolve(node.annotation)
            d = d + "()" if d else None
        k = key_of(node.target)
        if k:
            self._set_type(k, d if d and self.matcher.match(d) else None)

    def visit_NamedExpr(self, node):
        self.visit(node.value)
        d, _, _ = self.resolve(node.value)
        if d and self.matcher.match(d):
            self._set_type(node.target.id, d)

    def visit_With(self, node):
        for item in node.items:
            self.visit(item.context_expr)
            d, _, _ = self.resolve(item.context_expr)
            if item.optional_vars is not None:
                self.visit(item.optional_vars)
                k = key_of(item.optional_vars)
                if k and d and self.matcher.match(d):
                    self._set_type(k, d)
        for s in node.body:
            self.visit(s)

    visit_AsyncWith = visit_With


# --------------------------------------------------------------------------- whole-repo facts
class Facts:
    def __init__(self):
        self.analyzers: list[FileAnalyzer] = []
        self.functions: dict[str, FuncInfo] = {}
        self.by_simple: dict[str, list[str]] = defaultdict(list)
        self.callgraph: dict[str, set] = {}

    def index(self):
        for an in self.analyzers:
            for q, fi in an.functions.items():
                self.functions[q] = fi
                self.by_simple[q.rpartition(".")[2].rpartition(":")[2]].append(q)

    def _ctor(self, q):
        if q in self.functions:
            return q
        if q + ".__init__" in self.functions:
            return q + ".__init__"
        return None

    def resolve_callees(self, an, scope_parts, cls, func_expr):
        if isinstance(func_expr, ast.Name):
            n = func_expr.id
            full = an.alias.get(n)
            if full:
                mod, _, name = full.rpartition(".")
                q = self._ctor(f"{mod}:{name}")
                if q:
                    return [q]
            for k in range(len(scope_parts), -1, -1):
                q = self._ctor(f"{an.module}:{'.'.join(scope_parts[:k] + [n])}")
                if q:
                    return [q]
            return []
        if isinstance(func_expr, ast.Attribute):
            attr, base = func_expr.attr, func_expr.value
            if isinstance(base, ast.Name) and base.id in ("self", "cls") and cls:
                q = f"{an.module}:{cls}.{attr}"
                if q in self.functions:
                    return [q]
            bd, _, _ = an.resolve(base)
            if bd:
                q = self._ctor(f"{bd}:{attr}")
                if q:
                    return [q]
                mod, _, cn = bd.rpartition(".")
                q = f"{mod}:{cn}.{attr}"
                if q in self.functions:
                    return [q]
            cands = [q for q in self.by_simple.get(attr, []) if not self.functions[q].is_test_fn]
            if 0 < len(cands) <= 3:      # last-name fallback (heuristic)
                return cands
        return []

    def build_callgraph(self):
        for q, fi in self.functions.items():
            out = set()
            for call in fi.an.func_calls.get(q, []):
                for c in self.resolve_callees(fi.an, fi.scope_parts, fi.cls, call.func):
                    if c != q and not self.functions[c].is_test_fn:
                        out.add(c)
            # nested functions are reachable from their parent
            for q2, f2 in self.functions.items():
                if f2.an is fi.an and q2.startswith(q + ".") and q2 != q:
                    out.add(q2)
            self.callgraph[q] = out

    def closure(self, start, depth):
        seen, frontier = {start}, {start}
        for _ in range(depth):
            nxt = set()
            for f in frontier:
                nxt |= self.callgraph.get(f, set())
            nxt -= seen
            seen |= nxt
            frontier = nxt
            if not frontier:
                break
        return seen


# --------------------------------------------------------------------------- test flow ("asserted" heuristic)
class TestFlow(ast.NodeVisitor):
    """Walks one test function: which project functions' results reach an assertion."""

    def __init__(self, facts: Facts, fi: FuncInfo):
        self.facts, self.fi, self.an = facts, fi, fi.an
        self.taint: dict[str, set] = {}
        self.asserted: set = set()
        self.raised: set = set()
        self.called: set = set()
        self.mock_asserted = False

    def callees(self, call):
        return self.facts.resolve_callees(self.an, self.fi.scope_parts, self.fi.cls, call.func)

    def sources(self, expr) -> set:
        s = set()
        for n in ast.walk(expr):
            if isinstance(n, ast.Call):
                s.update(c for c in self.callees(n) if c != self.fi.qual)
                d, _, _ = self.an.resolve(n.func)
                if d and self.an.matcher.match(d):
                    s.add(f"usage@{self.an.relpath}:{n.lineno}")
            elif isinstance(n, ast.Name) and n.id in self.taint:
                s |= self.taint[n.id]
        return s

    def bind(self, target, srcs):
        if isinstance(target, ast.Name):
            if srcs:
                self.taint[target.id] = set(srcs)
            else:
                self.taint.pop(target.id, None)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for e in target.elts:
                self.bind(e, srcs)
        elif isinstance(target, ast.Starred):
            self.bind(target.value, srcs)
        else:
            root = target
            while isinstance(root, (ast.Attribute, ast.Subscript)):
                root = root.value
            if isinstance(root, ast.Name) and srcs:
                self.taint.setdefault(root.id, set()).update(srcs)

    def visit_FunctionDef(self, node):
        if node is self.fi.node:
            for s in node.body:
                self.visit(s)
    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_Assign(self, node):
        self.visit(node.value)
        srcs = self.sources(node.value)
        for t in node.targets:
            self.bind(t, srcs)

    def visit_AnnAssign(self, node):
        if node.value is not None:
            self.visit(node.value)
            self.bind(node.target, self.sources(node.value))

    def visit_AugAssign(self, node):
        self.visit(node.value)
        srcs = self.sources(node.value)
        if srcs:
            self.bind(node.target, srcs | self.taint.get(getattr(node.target, "id", ""), set()))

    def visit_NamedExpr(self, node):
        self.visit(node.value)
        self.bind(node.target, self.sources(node.value))

    def visit_For(self, node):
        self.visit(node.iter)
        self.bind(node.target, self.sources(node.iter))
        for s in node.body + node.orelse:
            self.visit(s)

    def visit_Assert(self, node):
        self.visit(node.test)
        self.asserted |= self.sources(node.test)

    def visit_With(self, node):
        raising = False
        for item in node.items:
            ctx = item.context_expr
            self.visit(ctx)
            if isinstance(ctx, ast.Call):
                f = ctx.func
                nm = f.attr if isinstance(f, ast.Attribute) else (f.id if isinstance(f, ast.Name) else "")
                if nm in RAISES_NAMES:
                    raising = True
                    continue
            if item.optional_vars is not None:
                self.bind(item.optional_vars, self.sources(ctx))
        if raising:
            for s in node.body:
                for n in ast.walk(s):
                    if isinstance(n, ast.Call):
                        self.raised.update(c for c in self.callees(n) if c != self.fi.qual)
                        d, _, _ = self.an.resolve(n.func)
                        if d and self.an.matcher.match(d):
                            self.raised.add(f"usage@{self.an.relpath}:{n.lineno}")
        for s in node.body:
            self.visit(s)

    visit_AsyncWith = visit_With

    def visit_Call(self, node):
        for c in self.callees(node):
            if c != self.fi.qual:
                self.called.add(c)
        f = node.func
        nm = f.attr if isinstance(f, ast.Attribute) else (f.id if isinstance(f, ast.Name) else "")
        if nm:
            if MOCK_ASSERT_RE.match(nm):
                self.mock_asserted = True
            elif re.match(r"assert[A-Z_]", nm):
                if nm in RAISES_NAMES:
                    for a in node.args[1:]:
                        self.raised |= self.sources(a)
                else:
                    for a in list(node.args) + [k.value for k in node.keywords]:
                        self.asserted |= self.sources(a)
        self.generic_visit(node)


def run_assert_heuristic(facts: Facts, depth: int):
    """-> (by_func, by_usage_site): func qual -> [(test, via, kind)], (file,line) -> [(test, kind)]."""
    by_func: dict[str, list] = defaultdict(list)
    by_site: dict[tuple, list] = defaultdict(list)
    for q, fi in facts.functions.items():
        if not fi.is_test_fn:
            continue
        tf = TestFlow(facts, fi)
        tf.visit(fi.node)
        test_id = f"{fi.an.relpath}::{'.'.join(fi.scope_parts)}"
        pairs = []
        for s in tf.asserted:
            pairs.append((s, "result"))
        for s in tf.raised:
            pairs.append((s, "raises"))
        if tf.mock_asserted:
            for s in tf.called:
                pairs.append((s, "mock_call"))
        for src, kind in pairs:
            if src.startswith("usage@"):
                f, _, ln = src[len("usage@"):].rpartition(":")
                by_site[(f, int(ln))].append((test_id, kind))
            elif src in facts.functions:
                for g in facts.closure(src, depth):
                    by_func[g].append((test_id, src, kind))
    return by_func, by_site


# --------------------------------------------------------------------------- coverage
def load_coverage(path: Path, root: Path):
    data = json.loads(path.read_text())
    cov = {}
    for fname, info in data.get("files", {}).items():
        p = Path(fname)
        try:
            rel = p.resolve().relative_to(root.resolve()).as_posix() if p.is_absolute() else Path(os.path.normpath(fname)).as_posix()
        except ValueError:
            rel = Path(fname).as_posix()
        cov[rel] = (set(info.get("executed_lines", [])), set(info.get("missing_lines", [])))
    return cov


def run_tests_under_coverage(root: Path, dirs, test_cmd: str, out_json: Path) -> bool:
    try:
        import coverage  # noqa: F401
    except ImportError:
        print("warning: the 'coverage' package is not installed; pip install coverage pytest "
              "(covered/asserted will be unknown)", file=sys.stderr)
        return False
    src = ",".join(d for d in dirs if (root / d).is_dir())
    env = dict(os.environ)
    env["COVERAGE_FILE"] = str(out_json.with_suffix(".data"))
    cmd = [sys.executable, "-m", "coverage", "run", "--branch", f"--source={src}"] + shlex.split(test_cmd)
    print("running:", " ".join(cmd), file=sys.stderr)
    r = subprocess.run(cmd, cwd=root, env=env)
    if r.returncode != 0:
        print(f"warning: baseline tests exited with code {r.returncode} (coverage still collected)", file=sys.stderr)
    r2 = subprocess.run([sys.executable, "-m", "coverage", "json", "-o", str(out_json)], cwd=root, env=env)
    return r2.returncode == 0 and out_json.exists()


def join_coverage(usages, cov):
    for u in usages:
        if cov is None:
            u.covered = None
            continue
        entry = cov.get(u.file)
        if entry is None:
            u.covered = False   # file never imported/measured
            continue
        executed, missing = entry
        lines = u.cov_lines
        if any(l in executed for l in lines):
            u.covered = True
        elif any(l in missing for l in lines):
            u.covered = False
        else:
            u.covered = None


# --------------------------------------------------------------------------- orchestration
def collect_files(root: Path, dirs):
    out = []
    for d in dirs:
        base = root / d
        if not base.is_dir():
            print(f"warning: directory {d}/ not found under {root}", file=sys.stderr)
            continue
        for p in sorted(base.rglob("*.py")):
            if any(part in SKIP_DIRS for part in p.parts):
                continue
            out.append(p.relative_to(root).as_posix())
    return out


def is_test_path(rel: str) -> bool:
    p = Path(rel)
    return p.parts[0] in ("tests", "test") or p.name.startswith("test_") or p.name == "conftest.py"


def analyze(root: Path, dirs, dep_modules, depth):
    files = collect_files(root, dirs)
    local_modules = {module_name_for(f) for f in files}
    matcher = DepMatcher(dep_modules)
    facts = Facts()
    for rel in files:
        src = (root / rel).read_text(errors="replace")
        try:
            tree = ast.parse(src, filename=rel)
        except SyntaxError as e:
            print(f"warning: skipping {rel}: {e}", file=sys.stderr)
            continue
        an = FileAnalyzer(rel, src, tree, module_name_for(rel), is_test_path(rel), local_modules, matcher)
        an.visit(tree)
        facts.analyzers.append(an)
    facts.index()
    facts.build_callgraph()

    usages: list[Usage] = []
    module_patches: dict[str, dict[str, set]] = defaultdict(lambda: defaultdict(set))
    for an in facts.analyzers:
        for u in an.usages:
            if u.kind == "monkeypatch" and u.func.endswith(":<module>"):
                module_patches[an.module][u.dep].add(u.symbol)
    for an in facts.analyzers:
        usages.extend(an.usages)
        for b in an.bindings:
            line_txt = an.lines[b.line - 1] if b.line - 1 < len(an.lines) else ""
            marked = bool(re.search(r"#\s*(noqa|side[- ]effect)", line_txt, re.I))
            unused = b.bound not in an.used_names and b.bound not in an.all_names and b.bound != "*"
            if b.usage is not None:                    # import of the dependency itself
                if unused or marked:
                    b.usage.side_effect = True
                    b.usage.note = "imported but never referenced in this file (possible import-for-side-effect)"
            if b.target_module and b.is_module_import and (unused or marked) and b.target_module in module_patches:
                for dep, syms in module_patches[b.target_module].items():
                    u = Usage(
                        dep=dep, kind="side_effect_import", symbol=b.target_module, file=an.relpath,
                        line=b.line, end_line=b.line, func=f"{an.module}:<module>", in_tests=an.is_test,
                        cov_lines=[b.line], local_name=b.bound, side_effect=True,
                        note=f"imports {b.target_module}, which monkeypatches: {', '.join(sorted(syms))}",
                        snippet=make_snippet(an.lines, b.line),
                    )
                    usages.append(u)
    seen, uniq = set(), []
    for u in usages:
        if u.key() not in seen:
            seen.add(u.key())
            uniq.append(u)
    usages = sorted(uniq, key=lambda u: (u.dep, u.file, u.line, u.kind, u.symbol))
    by_func, by_site = run_assert_heuristic(facts, depth)
    return facts, usages, by_func, by_site


def finalize(usages, by_func, by_site, have_cov):
    for u in usages:
        if u.kind in NA_KINDS:
            u.asserted = None
            continue
        hits = list(by_func.get(u.func, []))
        site = by_site.get((u.file, u.line), [])
        tests = [(t, t, k) for t, k in site]
        allh = hits + tests
        structural = bool(allh)
        if have_cov and u.covered is not True:
            u.asserted = False
            continue
        u.asserted = structural
        if structural:
            order = {"result": 0, "raises": 1, "mock_call": 2}
            allh.sort(key=lambda h: order[h[2]])
            u.assert_kind = allh[0][2]
            seen = []
            for t, via, k in allh:
                tag = f"{t} (via {via}, {k})" if via != t else f"{t} ({k})"
                if tag not in seen:
                    seen.append(tag)
            u.asserted_by = seen[:3]
        if u.func.endswith(":<module>") and not structural:
            u.note = (u.note + "; " if u.note else "") + "module-level usage: heuristic cannot follow its value into tests"


def summarize(usages, dep_names, have_cov):
    def tally(us):
        n = len(us)
        c = sum(1 for u in us if u.covered is True)
        a = sum(1 for u in us if u.asserted is True)
        return {"sites": n, "covered": c, "asserted": a,
                "covered_pct": round(100.0 * c / n, 1) if n and have_cov else None,
                "asserted_pct": round(100.0 * a / n, 1) if n and have_cov else None}

    per_dep = {}
    for d in dep_names:
        us = [u for u in usages if u.dep == d]
        prod = [u for u in us if u.kind in EXEC_KINDS and not u.in_tests]
        per_dep[d] = {
            "all_sites": tally(us), "prod_code_sites": tally(prod),
            "kinds": {k: sum(1 for u in us if u.kind == k) for k in sorted({u.kind for u in us})},
            "private": sum(1 for u in us if u.private),
            "monkeypatch": sum(1 for u in us if u.kind in ("monkeypatch", "side_effect_import")),
        }
    prod_all = [u for u in usages if u.kind in EXEC_KINDS and not u.in_tests]
    return {
        "coverage_available": have_cov,
        "usage_sites_covered": f"{sum(1 for u in prod_all if u.covered is True)}/{len(prod_all)}"
        if have_cov else "n/a",
        "scope": "production code (linkwatch/), kinds: call, attribute, reference, monkeypatch",
        "total": tally(prod_all), "all_sites_total": tally(usages), "per_dependency": per_dep,
    }


def build_observations(usages, dep_names):
    direct = {d: [u for u in usages if u.dep == d and u.kind in {"import"} | EXEC_KINDS] for d in dep_names}
    obs = {
        "zero_direct_usage": [d for d in dep_names if not direct[d]],
        "indirect_only": [d for d in dep_names if not direct[d] and any(u.dep == d for u in usages)],
        "private_api": [u for u in usages if u.private],
        "monkeypatch": [u for u in usages if u.kind in ("monkeypatch", "side_effect_import")],
        "side_effect_imports": [u for u in usages if u.side_effect],
        "test_patches": [u for u in usages if u.kind == "mock_patch"],
        "covered_not_asserted": [u for u in usages if u.kind in EXEC_KINDS and u.covered is True and u.asserted is False],
        "never_executed": [u for u in usages if u.covered is False],
    }
    return obs


# --------------------------------------------------------------------------- hand-off to Person C
def build_handoff(root: Path, facts: Facts, usages, have_cov):
    groups: dict[tuple, dict] = {}
    for u in usages:
        if u.in_tests or u.kind in ("mock_patch", "string_ref"):
            continue
        if u.kind == "import" and u.covered is not False:
            continue
        if u.kind == "side_effect_import" and u.covered is True:
            reason = "side-effect import: confirm the patch is still applied after migration"
        elif u.covered is False:
            reason = "uncovered"
        elif u.covered is True and u.asserted is False:
            reason = "covered_but_unasserted"
        elif u.covered is None and not have_cov and u.kind in EXEC_KINDS and u.asserted is False:
            reason = "unasserted_coverage_unknown"
        else:
            continue
        key = (u.file, u.func)
        g = groups.setdefault(key, {"file": u.file, "function": u.func, "sites": [], "dependencies": set()})
        g["dependencies"].add(u.dep)
        g["sites"].append({
            "line": u.line, "dependency": u.dep, "symbol": u.symbol, "kind": u.kind, "reason": reason,
            "covered": u.covered, "asserted": u.asserted, "private": u.private,
            "snippet": u.snippet, "note": u.note,
        })
    out = []
    for (f, qual), g in groups.items():
        fi = facts.functions.get(qual)
        if fi:
            lines = (root / f).read_text(errors="replace").splitlines()
            body = lines[fi.start - 1: fi.end]
            truncated = len(body) > 120
            g.update(function_lines=[fi.start, fi.end], function_source="\n".join(body[:120]),
                     truncated=truncated)
        else:
            g.update(function_lines=None, function_source=None, truncated=False)
        g["dependencies"] = sorted(g["dependencies"])
        g["sites"].sort(key=lambda s: s["line"])
        g["priority"] = (0 if any(s["private"] or s["kind"] in ("monkeypatch", "side_effect_import") for s in g["sites"])
                         else 1 if any(s["reason"] == "uncovered" for s in g["sites"]) else 2)
        out.append(g)
    out.sort(key=lambda g: (g["priority"], g["file"], g["function_lines"][0] if g["function_lines"] else 0))
    return out


def handoff_markdown(entries):
    md = ["# Characterization-test hand-off (Person B -> Person C)", "",
          "One entry per function that holds an uncovered or unasserted dependency usage. "
          "`asserted` is a heuristic (see README: Usage analysis).", ""]
    for e in entries:
        loc = f"{e['file']}:{e['function_lines'][0]}-{e['function_lines'][1]}" if e["function_lines"] else e["file"]
        md += [f"## `{e['function']}`  ({loc})", f"Dependencies: {', '.join(e['dependencies'])}", ""]
        for s in e["sites"]:
            flags = " PRIVATE" if s["private"] else ""
            md.append(f"- line {s['line']}: `{s['symbol']}` [{s['kind']}{flags}] -> **{s['reason']}**"
                      + (f" - {s['note']}" if s["note"] else ""))
        md += ["", "Function:", "```python", e["function_source"] or "\n".join(e["sites"][0]["snippet"].splitlines()),
               "```"]
        if e["truncated"]:
            md.append("(function truncated to 120 lines)")
        md += ["", "Snippets:"]
        for s in e["sites"]:
            md += ["```", s["snippet"], "```"]
        md.append("")
    return "\n".join(md)


# --------------------------------------------------------------------------- printing
def print_report(usages, dep_names, dep_modules, summary, obs, brief):
    for d in dep_names:
        us = [u for u in usages if u.dep == d]
        s = summary["per_dependency"][d]
        print("=" * 100)
        print(f"{d}  (import names tried: {', '.join(dep_modules[d])})  -  {len(us)} usage sites "
              f"(kinds: {s['kinds'] or 'none'})")
        print("=" * 100)
        if not us:
            print("  ZERO direct usage found in scanned dirs")
        for u in us:
            asserted = "n/a" if u.asserted is None else str(u.asserted)
            flags = [u.kind]
            if u.private:
                flags.append("PRIVATE-API")
            if u.kind in ("monkeypatch", "side_effect_import"):
                flags.append("MONKEYPATCH")
            if u.side_effect:
                flags.append("SIDE-EFFECT")
            if u.inferred:
                flags.append("inferred-type")
            if u.in_tests:
                flags.append("in-tests")
            cov = "?" if u.covered is None else str(u.covered)
            head = f"{u.file}:{u.line} | {u.symbol} | covered={cov} | asserted={asserted} | [{', '.join(flags)}]"
            print(head)
            if u.note:
                print(f"      note: {u.note}")
            if u.asserted_by and not brief:
                print(f"      asserted by: {'; '.join(u.asserted_by)}")
            if brief:
                print("      " + u.snippet.splitlines()[min(2, len(u.snippet.splitlines()) - 1)].strip())
            else:
                for ln in u.snippet.splitlines():
                    print("      " + ln)
        print()

    print("=" * 100)
    print("OBSERVATIONS")
    print("=" * 100)
    print("zero direct usage       :", obs["zero_direct_usage"] or "none")
    if obs["indirect_only"]:
        print("  (indirect refs only)  :", obs["indirect_only"])

    def lst(title, items, extra=lambda u: ""):
        print(f"{title}: {len(items)}")
        for u in items:
            print(f"   {u.dep:<14} {u.file}:{u.line}  {u.symbol}{extra(u)}")

    lst("private API usage (higher migration risk)", obs["private_api"])
    lst("monkeypatch / import-time patching (higher migration risk)", obs["monkeypatch"],
        lambda u: f"   [{u.note}]" if u.note else "")
    lst("test-time patch targets (tests break if the dependency is swapped)", obs["test_patches"])
    lst("covered but never asserted (heuristic)", obs["covered_not_asserted"])
    lst("never executed by baseline tests", obs["never_executed"])
    print()
    print("SUMMARY")
    print("-" * 100)
    for d in dep_names:
        s = summary["per_dependency"][d]["prod_code_sites"]
        if summary["coverage_available"]:
            print(f"  {d:<16} covered {s['covered']}/{s['sites']}  asserted {s['asserted']}/{s['sites']}  (production code)")
        else:
            print(f"  {d:<16} {s['sites']} production usage sites (no coverage data)")
    print(f"usage_sites_covered: {summary['usage_sites_covered']}"
          + (f" ({summary['total']['covered_pct']}%)" if summary["coverage_available"] and summary["total"]["sites"] else "")
          + f"   [{summary['scope']}]")
    if summary["coverage_available"]:
        print(f"usage_sites_asserted: {summary['total']['asserted']}/{summary['total']['sites']}"
              f" ({summary['total']['asserted_pct']}%)   [HEURISTIC - see README]")


# --------------------------------------------------------------------------- main
def main(argv=None):
    ap = argparse.ArgumentParser(description="Dependency usage finder + coverage join")
    ap.add_argument("--root", default=".")
    ap.add_argument("--dirs", nargs="+", default=["linkwatch", "tests"])
    ap.add_argument("--deps", help="comma-separated distribution names (default: from requirements*/pyproject, "
                                   "else all third-party imports found)")
    ap.add_argument("--exclude", default="", help="comma-separated dists to drop (e.g. pytest,coverage)")
    ap.add_argument("--map", action="append", default=[], metavar="DIST=MODULE[,MODULE]",
                    help="override dist -> import name(s), e.g. --map pyyaml=yaml")
    ap.add_argument("--coverage", help="existing coverage JSON to reuse (skips running tests)")
    ap.add_argument("--no-coverage", action="store_true", help="skip running tests; covered/asserted unknown")
    ap.add_argument("--test-cmd", default="-m pytest -q", help="args after 'coverage run ...' (default: -m pytest -q)")
    ap.add_argument("--out-dir", default="usage_out")
    ap.add_argument("--depth", type=int, default=3, help="call-graph depth for the asserted heuristic")
    ap.add_argument("--brief", action="store_true", help="one-line snippet in the printed report")
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    out_dir = Path(args.out_dir)
    if not out_dir.is_absolute():
        out_dir = root / out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    overrides = {}
    for m in args.map:
        dist, _, mods = m.partition("=")
        overrides[norm_dist(dist)] = [x for x in mods.split(",") if x]

    manifest_src = []
    if args.deps:
        dists = [d.strip() for d in args.deps.split(",") if d.strip()]
    else:
        dists, manifest_src = read_manifest_deps(root)
    exclude = {norm_dist(x) for x in args.exclude.split(",") if x}
    dists = [d for d in dists if norm_dist(d) not in exclude]
    if not dists:   # fall back: every third-party top-level import
        files = collect_files(root, args.dirs)
        local_tops = {module_name_for(f).split(".")[0] for f in files}
        found = set()
        for rel in files:
            try:
                tree = ast.parse((root / rel).read_text(errors="replace"))
            except SyntaxError:
                continue
            for n in ast.walk(tree):
                if isinstance(n, ast.Import):
                    found.update(a.name.split(".")[0] for a in n.names)
                elif isinstance(n, ast.ImportFrom) and n.level == 0 and n.module:
                    found.add(n.module.split(".")[0])
        std = getattr(sys, "stdlib_module_names", set())
        dists = sorted(x for x in found if x not in std and x not in local_tops and not x.startswith("_"))
        print(f"note: no manifest found; using third-party imports: {', '.join(dists)}", file=sys.stderr)
    dep_modules = {d: import_names_for(d, overrides) for d in dists}
    if manifest_src:
        print(f"note: target dependencies read from {', '.join(manifest_src)}", file=sys.stderr)

    facts, usages, by_func, by_site = analyze(root, args.dirs, dep_modules, args.depth)

    cov = None
    if args.coverage:
        cov = load_coverage(Path(args.coverage), root)
    elif not args.no_coverage:
        cj = out_dir / "coverage.json"
        if run_tests_under_coverage(root, args.dirs, args.test_cmd, cj):
            cov = load_coverage(cj, root)
    join_coverage(usages, cov)
    finalize(usages, by_func, by_site, cov is not None)

    summary = summarize(usages, dists, cov is not None)
    obs = build_observations(usages, dists)
    print_report(usages, dists, dep_modules, summary, obs, args.brief)

    handoff = build_handoff(root, facts, usages, cov is not None)
    imports = [{"name": u.dep, "module": u.symbol, "file": u.file, "line": u.line, "alias": u.local_name,
                "private": u.private, "side_effect": u.side_effect, "in_tests": u.in_tests}
               for u in usages if u.kind == "import"]
    clean = lambda u: {k: v for k, v in asdict(u).items() if k != "cov_lines"}
    (out_dir / "usage.json").write_text(json.dumps({
        "dependencies": dep_modules, "heuristic_note": "asserted = covered AND the enclosing function is reachable "
        "(call-graph depth %d) from a function whose result/exception/mock-call a test asserts on" % args.depth,
        "summary": summary, "usages": [clean(u) for u in usages]}, indent=2))
    (out_dir / "imports.json").write_text(json.dumps(imports, indent=2))
    (out_dir / "handoff.json").write_text(json.dumps(handoff, indent=2))
    (out_dir / "handoff.md").write_text(handoff_markdown(handoff))
    print(f"\nwrote {out_dir}/usage.json, imports.json (for A), handoff.json + handoff.md (for C)"
          f" - {len(handoff)} functions handed off")
    return 0


if __name__ == "__main__":
    sys.exit(main())
