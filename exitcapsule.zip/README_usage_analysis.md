## Usage analysis

`usage.py` finds how linkwatch actually uses each target dependency and joins that with test coverage.

```
pip install coverage pytest
python usage.py                      # deps from requirements*/pyproject, runs tests under coverage
python usage.py --deps requests,appdirs --exclude pytest --map pyyaml=yaml
python usage.py --coverage coverage.json     # reuse an existing coverage JSON
python usage.py --no-coverage --brief        # structure only
```

Outputs go to `usage_out/`: `usage.json` (all records + summary), `imports.json` (name, file, line for
Person A), `handoff.json` / `handoff.md` (for Person C), `coverage.json`.

### What is recorded
Per dependency, per usage site: `file:line | symbol | covered | asserted | snippet` (about 5 lines of context).

| kind | meaning |
|---|---|
| import | `import x`, `from x import y as z` (aliases resolved to the full dotted name) |
| call / attribute / reference | calls, non-call attribute access, bare references. Simple type inference follows `s = S()`, `with Session() as s`, `self.session = ...` and annotated parameters, so `s.get(...)` is reported as `requests.Session().get` (`inferred-type`). |
| monkeypatch | assignment to an attribute of the dependency (`requests.Session.request = f`), `setattr` on it |
| side_effect_import | an import whose bound name is unused (or marked `noqa`) and whose target module monkeypatches a dependency at import time (`from . import http_patch`) |
| mock_patch | test-time patch targets (`mock.patch("requests.get")`, `patch.object`, `monkeypatch.setattr`); these break if the dependency is swapped |
| string_ref | a string equal to the module name (low confidence) |

Private API: any name segment after the dependency root that starts with `_` (dunders excluded).

### covered
A usage is covered if the statement holding it (or the usage line itself) is in coverage's `executed_lines`.
Not covered means in `missing_lines`; `?` means coverage had no entry for that line.
Limitations: sub-expressions on a line that ran (`a or requests.get()`) and partial branches are not distinguished;
import lines are trivially covered, so the headline number counts production code only
(`call`, `attribute`, `reference`, `monkeypatch` in `linkwatch/`).

### asserted (HEURISTIC, deliberately simple)
`asserted = covered AND` the usage's enclosing function is reachable (call graph, depth 3) from a function
that a test calls and whose result reaches an assertion. Concretely, per test:
1. `r = f(...)`: taint `r`; taint propagates through later assignments, `with ... as`, and `for` targets.
2. `assert <expr with tainted name or a call to f>`, `self.assertX(...)` mark `f` asserted (kind `result`).
3. a call inside `pytest.raises` / `assertRaises` marks `f` asserted (kind `raises`).
4. if the test makes a mock check (`assert_called_with`, ...), the project functions it calls count (kind `mock_call`, weakest).
Known gaps: pytest fixtures, call resolution falls back to last-name matching (at most 3 candidates),
module-level usages are never `asserted`, and an assertion on `len(result)` counts like one on a field.
Treat `asserted=True` as "some test looks at the output", not as proof the dependency behaviour is pinned.

### Reading the output
- zero direct usage: listed first under OBSERVATIONS (also check `--map` if the import name differs from the dist name).
- private API / monkeypatch / side-effect imports: higher migration risk.
- covered but never asserted, and never executed (for example the `appdirs` fallback branch): handed to Person C.
- `usage_sites_covered: X/Y` is printed at the end and stored in `usage.json`.

### Hand-off to Person C
`handoff.md` lists, per function with an uncovered or unasserted usage: the dependency, the reason
(`uncovered`, `covered_but_unasserted`, side-effect import), the full function source and the snippets.
Highest-risk entries (private API, monkeypatch) come first.
