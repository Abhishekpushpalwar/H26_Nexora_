"""exitcapsule - run baseline vs candidate dependency swaps and render evidence capsules."""
__version__ = "0.1.0"
