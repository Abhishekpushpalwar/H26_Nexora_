"""selftest.py - offline end-to-end run on a synthetic repo.

No network: a local wheelhouse holds tiny fake packages (toml, appdirs, platformdirs) and a minimal
fake `pytest` that only understands --junitxml and test_* functions. It exercises every outcome
(regression, weak pass, patch failure, install failure, timeout, no plan). The capsules it produces
are SYNTHETIC examples of the format, not results about any real dependency.
"""
from __future__ import annotations

import json
import tempfile
import zipfile
from pathlib import Path

FAKE_PYTEST = r'''
import importlib.util, os, sys, time, traceback, unittest
from xml.sax.saxutils import escape, quoteattr

def collect(paths):
    files = []
    for p in paths:
        if os.path.isdir(p):
            for r, _, fs in os.walk(p):
                files += [os.path.join(r, f) for f in fs if f.startswith("test_") and f.endswith(".py")]
        elif p.endswith(".py"):
            files.append(p)
    return sorted(files)

def main(argv):
    junit, paths, skip = None, [], False
    for a in argv:
        if skip: skip = False; continue
        if a == "-p": skip = True; continue
        if a.startswith("--junitxml="): junit = a.split("=", 1)[1]
        elif not a.startswith("-"): paths.append(a)
    sys.path.insert(0, os.getcwd())
    cases = []
    for f in collect(paths):
        mod_name = f[:-3].replace(os.sep, ".")
        spec = importlib.util.spec_from_file_location(mod_name, f)
        mod = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(mod)
        except Exception as e:
            cases.append((mod_name, "collection", "error", f"{f}:1: {type(e).__name__}\nE   {type(e).__name__}: {e}", 0.0))
            continue
        for name in sorted(dir(mod)):
            fn = getattr(mod, name)
            if name.startswith("test_") and callable(fn):
                t0 = time.time()
                try:
                    fn(); cases.append((mod_name, name, "passed", "", time.time() - t0))
                except unittest.SkipTest as e:
                    cases.append((mod_name, name, "skipped", str(e), time.time() - t0))
                except BaseException as e:
                    frames = [fr for fr in traceback.extract_tb(e.__traceback__) if fr.filename.startswith(os.getcwd())]
                    lines = [f"{os.path.relpath(fr.filename)}:{fr.lineno}: " for fr in frames]
                    text = "\n".join(lines[:-1] + [lines[-1] + type(e).__name__ if lines else ""]) + f"\nE   {type(e).__name__}: {e}"
                    cases.append((mod_name, name, "failed", text, time.time() - t0))
    if junit:
        with open(junit, "w") as fh:
            fh.write('<?xml version="1.0"?><testsuites><testsuite name="fake">')
            for m, n, st, text, t in cases:
                fh.write(f'<testcase classname={quoteattr(m)} name={quoteattr(n)} time="{t:.3f}">')
                if st in ("failed", "error"):
                    tag = "failure" if st == "failed" else "error"
                    fh.write(f'<{tag} message={quoteattr(text.splitlines()[-1] if text else "")}>{escape(text)}</{tag}>')
                elif st == "skipped":
                    fh.write(f'<skipped message={quoteattr(text)}/>')
                fh.write('</testcase>')
            fh.write('</testsuite></testsuites>')
    bad = sum(1 for c in cases if c[2] in ("failed", "error"))
    print(f"{len(cases)} tests, {bad} failed")
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
'''


def make_wheel(dest: Path, name: str, version: str, files: dict):
    dist = f"{name}-{version}"
    path = dest / f"{dist}-py3-none-any.whl"
    info = {f"{dist}.dist-info/METADATA": f"Metadata-Version: 2.1\nName: {name}\nVersion: {version}\n",
            f"{dist}.dist-info/WHEEL": "Wheel-Version: 1.0\nGenerator: selftest\nRoot-Is-Purelib: true\nTag: py3-none-any\n"}
    allf = {**files, **info}
    record = "".join(f"{p},,\n" for p in allf) + f"{dist}.dist-info/RECORD,,\n"
    with zipfile.ZipFile(path, "w") as z:
        for p, c in allf.items():
            z.writestr(p, c)
        z.writestr(f"{dist}.dist-info/RECORD", record)


def write(p: Path, text: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)


def build(root: Path):
    wh = root / "wheelhouse"
    wh.mkdir(parents=True)
    make_wheel(wh, "pytest", "0.0.1", {"pytest/__init__.py": "", "pytest/__main__.py": FAKE_PYTEST})
    make_wheel(wh, "toml", "0.10.2", {"toml/__init__.py": (
        "def loads(s):\n    d = {}\n    for line in s.splitlines():\n        if '=' in line:\n"
        "            k, v = [x.strip() for x in line.split('=', 1)]\n"
        "            d[k] = v.strip('\"') if v.startswith('\"') else int(v)\n    return d\n\n\n"
        "def dumps(d):\n    return ''.join(f'{k} = {v!r}\\n' for k, v in d.items())\n")})
    for n, v in (("appdirs", "1.4.4"), ("platformdirs", "4.2.0")):
        make_wheel(wh, n, v, {f"{n}/__init__.py": "def user_cache_dir(app):\n    return '/c/' + app\n"})

    repo = root / "repo"
    write(repo / "requirements.txt", "toml==0.10.2\nappdirs==1.4.4\n")
    write(repo / "linkwatch/__init__.py", "")
    write(repo / "linkwatch/config.py", "import toml\n\n\ndef load(text):\n    return toml.loads(text)\n\n\n"
                                        "def dump(data):\n    return toml.dumps(data)\n")
    write(repo / "linkwatch/paths.py", "try:\n    import appdirs\nexcept ImportError:  # pragma: no cover\n    appdirs = None\n\n\n"
                                       "def cache_dir():\n    if appdirs is not None:\n        return appdirs.user_cache_dir('linkwatch')\n"
                                       "    return '/tmp/linkwatch-cache'\n")
    write(repo / "linkwatch/status.py", (
        "import datetime, sys, time\nfrom linkwatch import config, paths\n\n\ndef main(out):\n"
        "    cfg = config.load('name = \"demo\"\\ninterval = 30')\n"
        "    now = datetime.datetime.now().isoformat(timespec='seconds')\n"
        "    ms = int(time.time() * 1000) % 900\n"
        "    html = (f\"<html><body>\\n<h1>{cfg['name']}</h1>\\n<p>Generated at {now}</p>\\n<p>latency {ms} ms</p>\\n\"\n"
        "            f\"<p>cache {paths.cache_dir()}</p>\\n<p>interval {cfg['interval']}</p>\\n</body></html>\")\n"
        "    open(out, 'w').write(html)\n\n\nif __name__ == '__main__':\n    main(sys.argv[1])\n"))
    write(repo / "tests/test_config.py", "from linkwatch import config\n\n\ndef test_load():\n    assert config.load('a = 1') == {'a': 1}\n\n\n"
                                         "def test_dump():\n    assert config.dump({'a': 1}).strip() == 'a = 1'\n")
    write(repo / "tests/test_paths.py", "from linkwatch import paths\n\n\ndef test_cache_dir():\n    assert paths.cache_dir().endswith('linkwatch')\n")

    plans = root / "plans"
    write(plans / "toml.patch", "--- a/linkwatch/config.py\n+++ b/linkwatch/config.py\n@@ -1,4 +1,4 @@\n-import toml\n+import tomllib as toml\n \n \n def load(text):\n")
    write(plans / "toml_char/test_toml_char.py", "from linkwatch import config\n\n\ndef test_char_int():\n    assert config.load('n = 5')['n'] == 5\n")
    write(plans / "toml.json", json.dumps({
        "dependency": "toml", "replacement": "tomllib", "kind": "replace", "patch": "toml.patch",
        "swap": {"remove": ["toml"], "install": []}, "characterization_tests": "toml_char",
        "ai": {"model": "gemma (synthetic selftest text)", "summary": "toml.loads maps to tomllib.loads; toml.dumps has no stdlib equivalent.",
               "claims": ["tomllib is a drop-in for toml.loads and toml.dumps"],
               "validation_failures": ["claim 'drop-in for toml.dumps' not supported by the usage analysis"]}}))
    write(plans / "appdirs.patch", "--- a/linkwatch/paths.py\n+++ b/linkwatch/paths.py\n@@ -1,4 +1,4 @@\n try:\n-    import appdirs\n+    import platformdirs as appdirs\n except ImportError:  # pragma: no cover\n     appdirs = None\n")
    write(plans / "appdirs.json", json.dumps({
        "dependency": "appdirs", "replacement": "platformdirs", "kind": "replace", "patch": "appdirs.patch",
        "swap": {"remove": ["appdirs"], "install": ["platformdirs==4.2.0"]},
        "ai": {"model": "gemma (synthetic selftest text)", "summary": "platformdirs is the maintained successor of appdirs."}}))
    write(plans / "chardet.json", json.dumps({
        "dependency": "chardet", "replacement": "charset-normalizer", "kind": "replace",
        "patch_text": "--- a/linkwatch/encoding.py\n+++ b/linkwatch/encoding.py\n@@ -1,2 +1,2 @@\n-import chardet\n+import charset_normalizer\n x = 1\n y = 2\n",
        "swap": {"remove": ["chardet"], "install": ["charset-normalizer"]}}))
    write(plans / "six.json", json.dumps({
        "dependency": "six", "replacement": "(removed)", "kind": "remove",
        "swap": {"remove": ["six"], "install": ["six-replacement-does-not-exist==9.9"]}}))
    write(plans / "slowdep_char/test_slow.py", "import time\n\n\ndef test_slow():\n    time.sleep(100)\n")
    write(plans / "slowdep.json", json.dumps({"dependency": "slowdep", "replacement": "x", "swap": {},
                                              "characterization_tests": "slowdep_char"}))
    usage = {"usages": [
        {"dep": "toml", "kind": "call", "symbol": "toml.loads", "file": "linkwatch/config.py", "line": 5, "in_tests": False,
         "covered": True, "asserted": True, "private": False},
        {"dep": "toml", "kind": "call", "symbol": "toml.dumps", "file": "linkwatch/config.py", "line": 9, "in_tests": False,
         "covered": True, "asserted": True, "private": False},
        {"dep": "appdirs", "kind": "call", "symbol": "appdirs.user_cache_dir", "file": "linkwatch/paths.py", "line": 9,
         "in_tests": False, "covered": True, "asserted": True, "private": False},
        {"dep": "appdirs", "kind": "import", "symbol": "appdirs", "file": "linkwatch/paths.py", "line": 4, "in_tests": False,
         "covered": False, "asserted": None, "private": False}]}
    write(root / "usage.json", json.dumps(usage))
    return repo, plans, wh


def run(out="selftest_capsules"):
    from .__main__ import main
    root = Path(tempfile.mkdtemp(prefix="exitcapsule_selftest_"))
    repo, plans, wh = build(root)
    print(f"synthetic repo in {root} (wheelhouse offline; fake pytest). Capsules are synthetic examples.")
    return main(["run", str(repo), "--plans", str(plans), "--usage", str(root / "usage.json"), "--out", out,
                 "--deps", "idna", "--pip-args", f"--no-index --find-links {wh}",
                 "--status-cmd", "{python} -m linkwatch.status {out}", "--timeout", "40", "--baseline-timeout", "120"])
