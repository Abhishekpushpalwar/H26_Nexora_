"""python -m exitcapsule run <repo>   |   python -m exitcapsule selftest"""
from __future__ import annotations

import argparse
import shlex
import sys
import tempfile
from pathlib import Path

from . import orchestrator, runner
from .runner import Context


def cmd_run(a):
    repo = Path(a.repo).resolve()
    if not repo.is_dir():
        print(f"error: {repo} is not a directory", file=sys.stderr)
        return 2
    work = Path(a.work).resolve() if a.work else Path(tempfile.mkdtemp(prefix="exitcapsule_"))
    pyinfo = runner.find_python(a.python)
    ctx = Context(repo=repo, work=work, python=pyinfo["path"], test_paths=a.tests.split(","),
                  pytest_args=shlex.split(a.pytest_args or ""), pip_args=shlex.split(a.pip_args or ""),
                  status_cmd=a.status_cmd, live=a.live, run_anyway=a.run_anyway,
                  baseline_timeout=a.baseline_timeout, dep_timeout=a.timeout)
    plans_dir = a.plans or next((str(p) for p in (repo / "plans", Path("plans")) if p.is_dir()), None)
    plans = orchestrator.load_plans(plans_dir, work)
    wanted = [d for d in (a.only.split(",") if a.only else []) if d]
    deps = list(plans) + [d for d in (a.deps.split(",") if a.deps else []) if d and d not in plans]
    if wanted:
        deps = [d for d in deps if d in wanted]
    deps = orchestrator.order_deps(deps)
    if not deps:
        print("error: no dependencies: put plans/<dep>.json files in --plans or pass --deps", file=sys.stderr)
        return 2
    usage = a.usage or next((str(p) for p in (Path("usage_out/usage.json"), repo / "usage_out" / "usage.json") if p.exists()), None)
    out = Path(a.out).resolve()
    caps = orchestrator.orchestrate(ctx, plans, deps, usage, out, pyinfo, keep_work=a.keep_work)
    print(f"\n{'dependency':<18} {'outcome':<22} evidence")
    for c in caps:
        print(f"{c['dependency']:<18} {c['outcome']:<22} {c['evidence_strength']}")
    print(f"\ncapsules written to {out}/ (index.md, <dep>.json, <dep>.md)")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="exitcapsule")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="baseline + every dependency swap -> capsules")
    r.add_argument("repo")
    r.add_argument("--plans", help="dir of plans/<dep>.json (default: ./plans or <repo>/plans)")
    r.add_argument("--usage", help="usage.json from usage.py (default: usage_out/usage.json)")
    r.add_argument("--out", default="capsules")
    r.add_argument("--deps", help="comma list; deps without a plan get a no_plan capsule")
    r.add_argument("--only", help="comma list: run just these")
    r.add_argument("--python", help="interpreter for venvs (default: python3.12, then python3.13)")
    r.add_argument("--tests", default="tests", help="comma list of test paths (default: tests)")
    r.add_argument("--pytest-args", default="")
    r.add_argument("--pip-args", default="", help="extra pip install args, e.g. '--no-index --find-links wheelhouse'")
    r.add_argument("--status-cmd", help="command producing status.html; use {python} and {out}")
    r.add_argument("--live", action="store_true", help="status run uses the live network (flagged as non-deterministic)")
    r.add_argument("--run-anyway", action="store_true", help="run baseline tests even if pins failed to install")
    r.add_argument("--timeout", type=int, default=900, help="seconds per dependency (install+tests)")
    r.add_argument("--baseline-timeout", type=int, default=1200)
    r.add_argument("--work", help="work dir (default: temp)")
    r.add_argument("--keep-work", action="store_true")
    r.set_defaults(fn=cmd_run)
    s = sub.add_parser("selftest", help="offline end-to-end run on a synthetic repo")
    s.add_argument("--out", default="selftest_capsules")
    s.set_defaults(fn=lambda a: __import__("exitcapsule.selftest", fromlist=["x"]).run(a.out))
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
